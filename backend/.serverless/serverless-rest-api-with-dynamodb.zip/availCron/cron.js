'use strict';

const AWS = require('aws-sdk'); // eslint-disable-line import/no-extraneous-dependencies
const _ = require('lodash')
const Promise = require("bluebird");
const request = Promise.promisify(require("request"));

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const params = {
  TableName: process.env.AVAILS_DYNAMODB_TABLE,
};

// given a tables response 
function parseTablesResponse(response) {

}

module.exports.generateAvailsChecks = (event, context, callback) => {
  // fetch all seatAvail from the database
  dynamoDb.scan(params, (error, result) => {
    // handle potential errors
    if (error) {
      console.error(error);
      callback(new Error('Couldn\'t fetch the seatAvail.'));
      return;
    }

    // get the list of unique omnivoreLocationID's to query from results  
    // NOTE: currently only one ID 
    const omniID = result.Items.map((item) => item.omnivoreLocationID)[0];

    const options = {
      url: `https://api.omnivore.io/1.0/locations/${omniID}/tables`,
      headers: {
        'Api-Key': 'b7a4045a0d07410bb9bdae3662e96108'
      }
    };

    request(options).then(function(result) {
       // create a response
      const response = {
        omniID,
        result,
        statusCode: 200,
      };
      callback(null, response);
    });
  });
};